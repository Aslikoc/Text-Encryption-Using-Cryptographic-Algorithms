from flask import Flask, render_template, request
from caesar_cipher import caesar_encrypt, caesar_decrypt

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/encrypt', methods=['POST'])
def encrypt():
    plaintext = request.form['plaintext']
    key = int(request.form['key'])
    ciphertext = caesar_encrypt(plaintext, key)
    return render_template('result.html', result=ciphertext)

@app.route('/decrypt', methods=['POST'])
def decrypt():
    ciphertext = request.form['ciphertext']
    key = int(request.form['key'])
    plaintext = caesar_decrypt(ciphertext, key)
    return render_template('result.html', result=plaintext)

if __name__ == '__main__':
    app.run(debug=True)
