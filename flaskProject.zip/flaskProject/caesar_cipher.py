def caesar_encrypt(plaintext, key):
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    ciphertext = ""
    for char in plaintext.upper():
        if char in alphabet:
            shifted_char = alphabet[(alphabet.index(char) + key) % 26]
            ciphertext += shifted_char
        else:
            ciphertext += char
    return ciphertext

def caesar_decrypt(ciphertext, key):
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    plaintext = ""
    for char in ciphertext.upper():
        if char in alphabet:
            shifted_char = alphabet[(alphabet.index(char) - key) % 26]
            plaintext += shifted_char
        else:
            plaintext += char
    return plaintext
